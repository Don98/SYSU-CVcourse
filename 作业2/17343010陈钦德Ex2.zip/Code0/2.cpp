#include<iostream>
using namespace std;

int main()
{
	int a = 0,b = 10;
	cout << b + a++ << endl;
}